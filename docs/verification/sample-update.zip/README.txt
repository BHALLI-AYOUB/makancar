Makan showroom update

Run: npm run catalogue:apply -- path/to/this.zip
Then: npm run check && npm run build
Commit content/catalogue.json and any new public/vehicles files. Deploy with the existing Git/Vercel workflow.
This ZIP is an export, not a deployment.
